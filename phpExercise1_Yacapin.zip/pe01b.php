<?php
    echo "<html>";
    echo "<head>";
    echo "</head>";
    echo "<body>";
    echo "Hello World!";
    echo "</body>";
    echo "</html>";


phpinfo();

 ?>